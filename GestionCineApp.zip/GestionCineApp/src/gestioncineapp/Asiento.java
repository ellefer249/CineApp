/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioncineapp;

import java.io.Serializable;
/**
 *
 * @author DAW_T
 */
public class Asiento implements Serializable{

    private char letra;

    private int fila;

    private Espectador espectador;

    protected Asiento(char letra, int fila) {
        this.letra = letra;
        this.fila = fila;
        this.espectador = null;
        
    }

    protected char getLetra() {
        return letra;
    }

    protected int getFila() {
        return fila;
    }

    protected Espectador getEspectador() {
        return espectador;
    }

    public void setLetra(char letra) {
        this.letra = letra;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public void setEspectador(Espectador espectador) {
        this.espectador = espectador;
    }

    protected boolean ocupado() {
       return espectador != null;
    }

    @Override
    public String toString() {
        return "Asiento{" + "letra=" + letra + ", fila=" + fila + ", espectador=" + espectador + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + this.letra;
        hash = 97 * hash + this.fila;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Asiento other = (Asiento) obj;
        if (this.letra != other.letra) {
            return false;
        }
        return this.espectador == other.espectador;
    }

}
