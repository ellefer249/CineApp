/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioncineapp;

/**
 *
 * @author DAW_T
 */
public class Asiento {
     private char letra ;
    
    private int fila;
    
     private Espectador espectador;
    
     

    protected Asiento(char letra, int fila, Espectador espectador ) {
        this.letra = letra;
        this.fila = fila;
        this.espectador = null;
  
    }

    protected char getLetra() {
        return letra;
    }

    protected int getFila() {
        return fila;
    }

    protected Espectador getEspectador() {
        return espectador;
    }

    public void setLetra(char letra) {
        this.letra = letra;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public void setEspectador(Espectador espectador) {
        this.espectador = espectador;
    }

protected boolean  ocupado (Asiento asiento){
    if( asiento != null ){
        return true ;
    }else {
        return false;
    }
}    
    
    
    @Override
    public String toString() {
        return "Asiento{" + "letra=" + letra + ", fila=" + fila + ", espectador=" + espectador + '}';
    }
    
    
    
}
