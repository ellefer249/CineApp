/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestioncineapp;

import java.util.Scanner;

/**
 *
 * @author DAW_T
 */
public class GestionCineApp {

    static Scanner sc = new Scanner(System.in);
//    Nos piden hacer un programa sobre un cine que tienen un conjunto de asientos (estructurados en filas y columnas). 
//    Del cine nos interesa conocer la pel?cula que se est? reproduciendo, el precio de la entrada en el cine, asientos ocupados y libres, espectador en cada asiento, ...
//De las pel?culas nos interesa saber el t?tulo, duraci?n, edad m?nima y director. Del espectador, nos interesa saber su nombre, edad y el dinero que tiene.
//Los asientos son etiquetados por una letra (columna) y un n?mero (fila), la primera fila ser? la 1 y la primera letra ser? la A. Tambi?n deberemos saber si est? ocupado o no el asiento.

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Cine cine1;
        int opcion;
        char respuesta;
        String datos;
        cargarDatos();

        do {

            opcion = menu();
            try {

                switch (opcion) {
                    case 1://mostrar()  cine
                        mostrar();
                        break;

                    case 2://insertar espectador
                        break;
                    case 3://modifcar pelicula
                        break;
                    case 4://Mostrar informaci?n de espectadores.
                        break;

                    case 5://Ver asientos libres

                        break;

                    case 6://Cargar espectadores desde fichero de texto

                        break;

                    case 7://Modificar cine.

                        break;

                    case 8://Reiniciar Sala

                        break;

                    default:

                }
            } catch (NumberFormatException e1) {
                System.out.println("Error en main");
            }
        } while (opcion != 0);
    }//main

//       
    //1.- Ver informaci?n del cine.
    //2.- 
    //3.- Modifica pel?cula
    //4.- Mostrar informaci?n de espectadores
    //5.- Ver asientos libres
    //6.- 
    //7.- Modificar cine
    //8.- Reiniciar sala
    //0.- Salir
    //        
    //mai
    private static int menu() {
        int op;
        System.out.println("Menu");
        System.out.println("");
        System.out.println("1.- Ver informaci?n.");
        System.out.println("2.- Insertar un espectador en fila y letra.");
        System.out.println("3.- Modificar pelicula");
        System.out.println("4.- Mostrar informaci?n de espectadores.");
        System.out.println("5.- Ver asientos libres. ");
        System.out.println("6.- Cargar espectadores desde fichero de texto.");
        System.out.println("7.- Modificar cine.");
        System.out.println("8.- Reiniciar Sala.");
        System.out.println("0.- Salir.");
        System.out.println("\nElija opci?n:");
        try {
            op = leerEntero();
        } catch (NumberFormatException e) {
            System.out.println("Error al introducir dato");
            op = 12;//valor para default en main.
        }
        return op;
    }//menu

    private static int leerEntero() {
        return Integer.parseInt(sc.nextLine());

    }

    private static char leerChar() {
        try {
            return sc.nextLine().charAt(0);
        } catch (Exception e) {
            return 'n';//en caso error se devuelve 'n'
        }
    }

    private static String leerString() {
        return sc.nextLine();
    }

    static void cargarDatos() {

    }

    private static void mostrar() {

    }

}
