/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestioncineapp;

/**
 *
 * @author DAW_T
 */
public class GestionCineApp {

    
//    Nos piden hacer un programa sobre un cine que tienen un conjunto de asientos (estructurados en filas y columnas). 
//    Del cine nos interesa conocer la pel?cula que se est? reproduciendo, el precio de la entrada en el cine, asientos ocupados y libres, espectador en cada asiento, ...
//De las pel?culas nos interesa saber el t?tulo, duraci?n, edad m?nima y director. Del espectador, nos interesa saber su nombre, edad y el dinero que tiene.
//Los asientos son etiquetados por una letra (columna) y un n?mero (fila), la primera fila ser? la 1 y la primera letra ser? la A. Tambi?n deberemos saber si est? ocupado o no el asiento.
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    
        
        
        
        
        
        
        
        
        
//       
//1.- Ver informaci?n del cine.
//2.- Insertar un espectador en fila y letra
//3.- Modifica pel?cula
//4.- Mostrar informaci?n de espectadores
//5.- Ver asientos libres
//6.- Cargar espectadores desde fichero de texto
//7.- Modificar cine
//8.- Reiniciar sala
//0.- Salir
//        
        
        
        
        
    
    }
    
}
