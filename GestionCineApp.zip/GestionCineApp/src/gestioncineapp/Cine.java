/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioncineapp;

import java.util.ArrayList;

/**
 *
 * @author DAW_T
 */
public class Cine {
    
    private  ArrayList<Asiento>  asientos;
    
    private int maxAsientos;
    
    private  double precio;
    
    private Pelicula pelicula ;
            
    private int filas; 
    
    private int columnas;

//    
//    Constructor: recibe (precio, pelicula, filas, columnas), crea el ArrayList asientos, maxAsientos
//    lo inicializa a filas*columnas, asigna a cada butaca su fila 
//    y letra correspondiente. Para ello se puede recurrir a un m?todo que realice esta funci?n. 
//            Nota: hay que tener en cuenta que los caracteres
//            se pueden sumar, A+1 =B, A+2=C, ...
//    
    public Cine(double precio, Pelicula pelicula, int filas, int columnas) {
        this.maxAsientos = filas * columnas;
        this.precio = precio;
        this.pelicula = pelicula;
        this.filas = filas;
        this.columnas = columnas;
        this.asientos= new ArrayList (); 
    }

    public ArrayList<Asiento> getAsientos() {
        return asientos;
    }

    public int getMaxAsientos() {
        return maxAsientos;
    }

    public double getPrecio() {
        return precio;
    }

    public Pelicula getPelicula() {
        return pelicula;
    }

    public int getFilas() {
        return filas;
    }

    public int getColumnas() {
        return columnas;
    }

    public void setAsientos(ArrayList<Asiento> asientos) {
        this.asientos = asientos;
    }

    public void setMaxAsientos(int maxAsientos) {
        this.maxAsientos = maxAsientos;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setPelicula(Pelicula pelicula) {
        this.pelicula = pelicula;
    }

    public void setFilas(int filas) {
        this.filas = filas;
    }

    public void setColumnas(int columnas) {
        this.columnas = columnas;
    }
    
    protected boolean  haySitio( ){
        if ( asientos = null)  {
          return true;
      }else {
          return false;
      }
      
    }
           
    
    
}
