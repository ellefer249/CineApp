/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioncineapp;

/**
 *
 * @author DAW_T
 */
class Espectador {
    
    private String nombre;
    
    private int edad;
    
    private double dinero;

    public Espectador(String nombre, int edad, double dinero) {
        this.nombre = nombre;
        this.edad = edad;
        this.dinero = dinero;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public double getDinero() {
        return dinero;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setDinero(double dinero) {
        this.dinero = dinero;
    }

    @Override
    public String toString() {
        return "Espectador{" + "nombre=" + nombre + ", edad=" + edad + ", dinero=" + dinero + '}';
    }
    
    
    protected void pagar(precio)
    
//    void pagar(precio), recibe el precio de la entrada y descuenta dicha cantidad del dinero disponible.
//
//boolean tieneEdad(edadMinima), comprueba si el espectador tiene edad para ver la pel?cula.
//
//boolean tieneDinero (precio), comprueba si tiene suficiente dinero para pagar la entrada.
//    
    
}
