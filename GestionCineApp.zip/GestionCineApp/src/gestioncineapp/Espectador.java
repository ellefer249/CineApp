/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestioncineapp;

import java.io.Serializable;

/**
 *
 * @author DAW_T
 */
public class Espectador  implements Serializable{

    private String nombre;

    private int edad;

    private double dinero;

    public Espectador(String nombre, int edad, double dinero) {
        this.nombre = nombre;
        this.edad = edad;
        this.dinero = dinero;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public double getDinero() {
        return dinero;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setDinero(double dinero) {
        this.dinero = dinero;
    }
    
    @Override
    public String toString() {
        return "Espectador{" + "nombre=" + nombre + ", edad=" + edad + 
                ", dinero=" + dinero + '}';
    }

    protected void pagar( double precio) {
        this.dinero -=precio;
     }

    protected boolean tieneEdad(int edadMinima) {
        return  this.edad >= edadMinima;
    }

    protected boolean tieneDinero(double precioEntrada) {
        boolean valido = false;
        if (dinero >= precioEntrada) {
            valido = true;
        }
        return valido;

    }
//    void pagar(precio), recibe el precio de la entrada y descuenta dicha cantidad del dinero disponible.
//
//boolean tieneEdad(edadMinima), comprueba si el espectador tiene edad para ver la pel?cula.
//
//boolean tieneDinero (precio), comprueba si tiene suficiente dinero para pagar la entrada.
//    

}
